<?php

/** * Runs on plugin activation */

include_once __DIR__ . '/scripts/create_access.php';
require_once __DIR__ . '/scripts/installer.php';
