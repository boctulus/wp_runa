<?php

namespace boctulus\SW\controllers;

use boctulus\SW\core\libs\Logger;

/*
    Registrar actions aqui
*/
class RegisterController
{    
    function index(){
        
    }
}