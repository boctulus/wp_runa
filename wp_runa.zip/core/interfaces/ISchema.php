<?php

namespace boctulus\SW\core\interfaces;

interface ISchema {
    static function get(); 
}
