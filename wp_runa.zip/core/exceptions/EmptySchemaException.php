<?php

namespace boctulus\SW\exceptions;

class EmptySchemaException extends \Exception {}