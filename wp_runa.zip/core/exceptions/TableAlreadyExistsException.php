<?php

namespace boctulus\SW\exceptions;

class TableAlreadyExistsException extends \Exception {}