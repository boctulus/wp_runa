<?php

namespace boctulus\SW\exceptions;

class SqlException extends \Exception {

}