<?php

global $wpdb;

