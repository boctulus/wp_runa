<?php

/*
    Routes for Router

    Nota: la ruta mas general debe colocarse al final
*/

return [
    '/cart/quote'  => 'boctulus\SW\controllers\CartController@save_form',
    '/cart/empty'  => 'boctulus\SW\controllers\CartController@empty',
];
